import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../students_list_screen/students_list_screen.dart';
import './widgets/form_field_group_widget.dart';
import './widgets/form_photo_picker_widget.dart';

// TODO: Replace with Riverpod/Bloc for production

class StudentFormScreen extends StatefulWidget {
  const StudentFormScreen({super.key});

  @override
  State<StudentFormScreen> createState() => _StudentFormScreenState();
}

class _StudentFormScreenState extends State<StudentFormScreen>
    with TickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production

  final _formKey = GlobalKey<FormState>();
  late AnimationController _entranceController;
  late Animation<double> _entranceAnimation;

  // Form fields
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  String _selectedClass = 'Turma A';
  String _selectedGrade = '5º Ano';
  DateTime? _birthDate;
  String _photoUrl = '';
  bool _isSubmitting = false;
  bool _isEditMode = false;
  Student? _editingStudent;

  final List<String> _classOptions = [
    'Turma A',
    'Turma B',
    'Turma C',
    'Turma D',
  ];

  final List<String> _gradeOptions = [
    '1º Ano',
    '2º Ano',
    '3º Ano',
    '4º Ano',
    '5º Ano',
    '6º Ano',
    '7º Ano',
    '8º Ano',
    '9º Ano',
  ];

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _entranceAnimation = CurvedAnimation(
      parent: _entranceController,
      curve: Curves.easeOutCubic,
    );
    _entranceController.forward();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null && !_isEditMode) {
      final student = args['student'] as Student?;
      if (student != null) {
        _isEditMode = true;
        _editingStudent = student;
        _nameController.text = student.name;
        _emailController.text = student.email;
        _phoneController.text = student.phone;
        _selectedClass = student.className;
        _selectedGrade = student.grade;
        _birthDate = student.birthDate;
        _photoUrl = student.photoUrl;
      }
    }
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  bool get _isTablet => MediaQuery.of(context).size.width >= 600;

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate:
          _birthDate ?? DateTime.now().subtract(const Duration(days: 365 * 10)),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      locale: const Locale('pt', 'BR'),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(
              context,
            ).colorScheme.copyWith(primary: AppTheme.primary),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() => _birthDate = picked);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_birthDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Selecione a data de nascimento',
            style: GoogleFonts.manrope(
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppTheme.warning,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          margin: const EdgeInsets.all(16),
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    // TODO: Replace with real API call
    await Future.delayed(const Duration(milliseconds: 800));

    if (mounted) {
      final student = Student(
        id: _isEditMode
            ? _editingStudent!.id
            : 's${DateTime.now().millisecondsSinceEpoch}',
        name: _nameController.text.trim(),
        photoUrl: _photoUrl.isNotEmpty
            ? _photoUrl
            : 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?w=200',
        photoSemanticLabel: 'Foto do aluno ${_nameController.text.trim()}',
        birthDate: _birthDate!,
        className: _selectedClass,
        grade: _selectedGrade,
        email: _emailController.text.trim(),
        phone: _phoneController.text.trim(),
        enrollmentDate: _isEditMode
            ? _editingStudent!.enrollmentDate
            : DateTime.now(),
      );

      setState(() => _isSubmitting = false);
      Navigator.pop(context, student);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceLight,
        elevation: 0,
        scrolledUnderElevation: 1,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            size: 20,
            color: theme.colorScheme.onSurface,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEditMode ? 'Editar Aluno' : 'Novo Aluno',
          style: GoogleFonts.manrope(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: theme.colorScheme.onSurface,
          ),
        ),
        centerTitle: false,
      ),
      body: SafeArea(
        child: FadeTransition(
          opacity: _entranceAnimation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.04),
              end: Offset.zero,
            ).animate(_entranceAnimation),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: _isTablet ? 32 : 16,
                  vertical: 20,
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      maxWidth: _isTablet ? 680 : double.infinity,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Photo picker
                        FormPhotoPickerWidget(
                          photoUrl: _photoUrl,
                          studentName: _nameController.text,
                          onPhotoChanged: (url) =>
                              setState(() => _photoUrl = url),
                        ),
                        const SizedBox(height: 20),

                        // Personal info group
                        FormFieldGroupWidget(
                          title: 'Dados Pessoais',
                          iconName: 'person',
                          children: [
                            _buildNameField(theme),
                            const SizedBox(height: 14),
                            _buildDateField(theme),
                          ],
                        ),
                        const SizedBox(height: 16),

                        // Academic info group
                        FormFieldGroupWidget(
                          title: 'Informações Acadêmicas',
                          iconName: 'school',
                          children: [
                            _isTablet
                                ? Row(
                                    children: [
                                      Expanded(
                                        child: _buildClassDropdown(theme),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: _buildGradeDropdown(theme),
                                      ),
                                    ],
                                  )
                                : Column(
                                    children: [
                                      _buildClassDropdown(theme),
                                      const SizedBox(height: 14),
                                      _buildGradeDropdown(theme),
                                    ],
                                  ),
                          ],
                        ),
                        const SizedBox(height: 16),

                        // Contact info group
                        FormFieldGroupWidget(
                          title: 'Contato',
                          iconName: 'email',
                          children: [
                            _buildEmailField(theme),
                            const SizedBox(height: 14),
                            _buildPhoneField(theme),
                          ],
                        ),
                        const SizedBox(height: 32),

                        // Submit button
                        _buildSubmitButton(theme),
                        const SizedBox(height: 16),

                        // Cancel
                        TextButton(
                          onPressed: _isSubmitting
                              ? null
                              : () => Navigator.pop(context),
                          child: Text(
                            'Cancelar',
                            style: GoogleFonts.manrope(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNameField(ThemeData theme) {
    return TextFormField(
      controller: _nameController,
      textCapitalization: TextCapitalization.words,
      style: GoogleFonts.manrope(
        fontSize: 15,
        fontWeight: FontWeight.w400,
        color: theme.colorScheme.onSurface,
      ),
      decoration: _fieldDecoration(
        label: 'Nome completo',
        hint: 'Ex: Ana Beatriz Santos',
        iconName: 'person',
        theme: theme,
      ),
      validator: (v) {
        if (v == null || v.trim().isEmpty) return 'Nome é obrigatório';
        if (v.trim().length < 3) return 'Nome deve ter ao menos 3 caracteres';
        return null;
      },
    );
  }

  Widget _buildDateField(ThemeData theme) {
    return GestureDetector(
      onTap: _pickDate,
      child: Container(
        height: 56,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: AppTheme.surfaceVariantLight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _birthDate != null
                ? AppTheme.primary
                : AppTheme.outlineLight,
            width: _birthDate != null ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: 'cake',
              size: 20,
              color: _birthDate != null
                  ? AppTheme.primary
                  : theme.colorScheme.onSurfaceVariant,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Data de nascimento',
                    style: GoogleFonts.manrope(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: _birthDate != null
                          ? AppTheme.primary
                          : theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  Text(
                    _birthDate != null
                        ? _formatDate(_birthDate!)
                        : 'DD/MM/AAAA',
                    style: GoogleFonts.manrope(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: _birthDate != null
                          ? theme.colorScheme.onSurface
                          : theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            CustomIconWidget(
              iconName: 'calendar_today',
              size: 18,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildClassDropdown(ThemeData theme) {
    return _DropdownField(
      label: 'Turma',
      iconName: 'class',
      value: _selectedClass,
      options: _classOptions,
      onChanged: (v) => setState(() => _selectedClass = v!),
      theme: theme,
    );
  }

  Widget _buildGradeDropdown(ThemeData theme) {
    return _DropdownField(
      label: 'Série',
      iconName: 'grade',
      value: _selectedGrade,
      options: _gradeOptions,
      onChanged: (v) => setState(() => _selectedGrade = v!),
      theme: theme,
    );
  }

  Widget _buildEmailField(ThemeData theme) {
    return TextFormField(
      controller: _emailController,
      keyboardType: TextInputType.emailAddress,
      style: GoogleFonts.manrope(
        fontSize: 15,
        fontWeight: FontWeight.w400,
        color: theme.colorScheme.onSurface,
      ),
      decoration: _fieldDecoration(
        label: 'E-mail',
        hint: 'aluno@escola.edu.br',
        iconName: 'email',
        theme: theme,
      ),
      validator: (v) {
        if (v == null || v.trim().isEmpty) return 'E-mail é obrigatório';
        if (!RegExp(r'^[\w.-]+@[\w.-]+\.\w+$').hasMatch(v.trim())) {
          return 'E-mail inválido';
        }
        return null;
      },
    );
  }

  Widget _buildPhoneField(ThemeData theme) {
    return TextFormField(
      controller: _phoneController,
      keyboardType: TextInputType.phone,
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
        _PhoneInputFormatter(),
      ],
      style: GoogleFonts.manrope(
        fontSize: 15,
        fontWeight: FontWeight.w400,
        color: theme.colorScheme.onSurface,
      ),
      decoration: _fieldDecoration(
        label: 'Telefone',
        hint: '(11) 99999-9999',
        iconName: 'phone',
        theme: theme,
      ),
      validator: (v) {
        if (v == null || v.trim().isEmpty) return 'Telefone é obrigatório';
        if (v.replaceAll(RegExp(r'\D'), '').length < 10) {
          return 'Telefone inválido';
        }
        return null;
      },
    );
  }

  Widget _buildSubmitButton(ThemeData theme) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      height: 52,
      child: FilledButton(
        onPressed: _isSubmitting ? null : _submit,
        style: FilledButton.styleFrom(
          backgroundColor: AppTheme.primary,
          disabledBackgroundColor: AppTheme.primary.withAlpha(153),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        child: _isSubmitting
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  color: Colors.white,
                ),
              )
            : Text(
                _isEditMode ? 'Salvar Alterações' : 'Cadastrar Aluno',
                style: GoogleFonts.manrope(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
      ),
    );
  }

  InputDecoration _fieldDecoration({
    required String label,
    required String hint,
    required String iconName,
    required ThemeData theme,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: Padding(
        padding: const EdgeInsets.only(left: 12, right: 8),
        child: CustomIconWidget(
          iconName: iconName,
          size: 20,
          color: theme.colorScheme.onSurfaceVariant,
        ),
      ),
      prefixIconConstraints: const BoxConstraints(minWidth: 44, minHeight: 44),
      filled: true,
      fillColor: AppTheme.surfaceVariantLight,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppTheme.outlineLight, width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppTheme.outlineLight, width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppTheme.primary, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppTheme.error, width: 1),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppTheme.error, width: 2),
      ),
      labelStyle: GoogleFonts.manrope(
        fontSize: 13,
        fontWeight: FontWeight.w500,
        color: theme.colorScheme.onSurfaceVariant,
      ),
      hintStyle: GoogleFonts.manrope(
        fontSize: 13,
        color: theme.colorScheme.onSurfaceVariant,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    );
  }
}

class _PhoneInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final digits = newValue.text.replaceAll(RegExp(r'\D'), '');
    String formatted = '';
    if (digits.isEmpty) return newValue.copyWith(text: '');
    if (digits.length <= 2) {
      formatted = '(${digits.substring(0, digits.length)}';
    } else if (digits.length <= 6) {
      formatted = '(${digits.substring(0, 2)}) ${digits.substring(2)}';
    } else if (digits.length <= 10) {
      formatted =
          '(${digits.substring(0, 2)}) ${digits.substring(2, 6)}-${digits.substring(6)}';
    } else {
      formatted =
          '(${digits.substring(0, 2)}) ${digits.substring(2, 7)}-${digits.substring(7, 11)}';
    }
    return newValue.copyWith(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }
}

class _DropdownField extends StatelessWidget {
  final String label;
  final String iconName;
  final String value;
  final List<String> options;
  final ValueChanged<String?> onChanged;
  final ThemeData theme;

  const _DropdownField({
    required this.label,
    required this.iconName,
    required this.value,
    required this.options,
    required this.onChanged,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceVariantLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.outlineLight),
      ),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        onChanged: onChanged,
        style: GoogleFonts.manrope(
          fontSize: 15,
          fontWeight: FontWeight.w400,
          color: theme.colorScheme.onSurface,
        ),
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Padding(
            padding: const EdgeInsets.only(left: 12, right: 8),
            child: CustomIconWidget(
              iconName: iconName,
              size: 20,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          prefixIconConstraints: const BoxConstraints(
            minWidth: 44,
            minHeight: 44,
          ),
          filled: false,
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          labelStyle: GoogleFonts.manrope(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: theme.colorScheme.onSurfaceVariant,
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 0,
            vertical: 4,
          ),
        ),
        items: options
            .map(
              (o) => DropdownMenuItem(
                value: o,
                child: Text(
                  o,
                  style: GoogleFonts.manrope(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            )
            .toList(),
        dropdownColor: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(12),
        icon: Padding(
          padding: const EdgeInsets.only(right: 8),
          child: CustomIconWidget(
            iconName: 'expand_more',
            size: 20,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}
