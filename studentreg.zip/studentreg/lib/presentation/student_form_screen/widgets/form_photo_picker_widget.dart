import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';

class FormPhotoPickerWidget extends StatelessWidget {
  final String photoUrl;
  final String studentName;
  final ValueChanged<String> onPhotoChanged;

  const FormPhotoPickerWidget({
    super.key,
    required this.photoUrl,
    required this.studentName,
    required this.onPhotoChanged,
  });

  void _showPhotoOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.outlineLight,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Foto do Aluno',
                style: GoogleFonts.manrope(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 16),
              // TODO: Replace with real image_picker integration
              _PhotoOptionTile(
                iconName: 'camera_alt',
                label: 'Tirar foto',
                subtitle: 'Usar câmera do dispositivo',
                onTap: () {
                  Navigator.pop(ctx);
                  // TODO: Launch camera
                },
              ),
              const SizedBox(height: 8),
              _PhotoOptionTile(
                iconName: 'photo_library',
                label: 'Escolher da galeria',
                subtitle: 'Selecionar foto existente',
                onTap: () {
                  Navigator.pop(ctx);
                  // TODO: Launch gallery picker
                },
              ),
              if (photoUrl.isNotEmpty) ...[
                const SizedBox(height: 8),
                _PhotoOptionTile(
                  iconName: 'delete',
                  label: 'Remover foto',
                  subtitle: 'Usar avatar padrão',
                  onTap: () {
                    Navigator.pop(ctx);
                    onPhotoChanged('');
                  },
                  isDestructive: true,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Column(
        children: [
          GestureDetector(
            onTap: () => _showPhotoOptions(context),
            child: Stack(
              children: [
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppTheme.primaryContainer,
                      width: 3,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.primary.withAlpha(38),
                        blurRadius: 16,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: photoUrl.isNotEmpty
                        ? CustomImageWidget(
                            imageUrl: photoUrl,
                            width: 96,
                            height: 96,
                            fit: BoxFit.cover,
                            semanticLabel: studentName.isNotEmpty
                                ? 'Foto do aluno $studentName'
                                : 'Foto do aluno',
                          )
                        : Container(
                            color: AppTheme.surfaceVariantLight,
                            child: Center(
                              child: CustomIconWidget(
                                iconName: 'person',
                                size: 40,
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: AppTheme.primary,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: Center(
                      child: CustomIconWidget(
                        iconName: 'camera_alt',
                        size: 14,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Toque para adicionar foto',
            style: GoogleFonts.manrope(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _PhotoOptionTile extends StatelessWidget {
  final String iconName;
  final String label;
  final String subtitle;
  final VoidCallback onTap;
  final bool isDestructive;

  const _PhotoOptionTile({
    required this.iconName,
    required this.label,
    required this.subtitle,
    required this.onTap,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = isDestructive ? AppTheme.error : theme.colorScheme.onSurface;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppTheme.surfaceVariantLight,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isDestructive
                    ? AppTheme.error.withAlpha(26)
                    : AppTheme.primaryContainer,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: iconName,
                  size: 20,
                  color: isDestructive ? AppTheme.error : AppTheme.primary,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: GoogleFonts.manrope(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: color,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: GoogleFonts.manrope(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
