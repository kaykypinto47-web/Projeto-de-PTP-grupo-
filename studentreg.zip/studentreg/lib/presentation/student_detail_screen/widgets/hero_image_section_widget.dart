import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../students_list_screen/students_list_screen.dart';

// Anatomy locked: full-bleed image top ~45% height, Stack overlays:
// back button top-left + edit/delete icons top-right

class HeroImageSectionWidget extends StatelessWidget {
  final Student student;
  final VoidCallback onBack;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final bool isTablet;

  const HeroImageSectionWidget({
    super.key,
    required this.student,
    required this.onBack,
    required this.onEdit,
    required this.onDelete,
    this.isTablet = false,
  });

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final heroHeight = isTablet ? 260.0 : screenHeight * 0.42;

    return SizedBox(
      height: heroHeight,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Hero image
          Hero(
            tag: 'student-avatar-${student.id}',
            child: CustomImageWidget(
              imageUrl: student.photoUrl,
              width: double.infinity,
              height: heroHeight,
              fit: BoxFit.cover,
              semanticLabel: student.photoSemanticLabel,
            ),
          ),
          // Gradient overlay bottom
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: heroHeight * 0.4,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black.withAlpha(128), Colors.transparent],
                ),
              ),
            ),
          ),
          // Gradient overlay top (for buttons visibility)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 100,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black.withAlpha(77), Colors.transparent],
                ),
              ),
            ),
          ),
          // Top controls
          Positioned(
            top: MediaQuery.of(context).padding.top + 12,
            left: 16,
            right: 16,
            child: Row(
              children: [
                _HeroIconButton(
                  iconName: 'arrow_back',
                  onTap: onBack,
                  tooltip: 'Voltar',
                ),
                const Spacer(),
                _HeroIconButton(
                  iconName: 'edit',
                  onTap: onEdit,
                  tooltip: 'Editar',
                ),
                const SizedBox(width: 8),
                _HeroIconButton(
                  iconName: 'delete',
                  onTap: onDelete,
                  tooltip: 'Excluir',
                  isDestructive: true,
                ),
              ],
            ),
          ),
          // Bottom name overlay
          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(51),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(
                      color: Colors.white.withAlpha(102),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    '${student.className} · ${student.grade}',
                    style: GoogleFonts.manrope(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroIconButton extends StatelessWidget {
  final String iconName;
  final VoidCallback onTap;
  final String tooltip;
  final bool isDestructive;

  const _HeroIconButton({
    required this.iconName,
    required this.onTap,
    required this.tooltip,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: isDestructive
                ? AppTheme.error.withAlpha(217)
                : Colors.white.withAlpha(217),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(38),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Center(
            child: CustomIconWidget(
              iconName: iconName,
              size: 18,
              color: isDestructive ? Colors.white : AppTheme.primary,
            ),
          ),
        ),
      ),
    );
  }
}
