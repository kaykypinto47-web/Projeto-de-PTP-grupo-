import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../students_list_screen/students_list_screen.dart';

class StudentAcademicCardWidget extends StatelessWidget {
  final Student student;

  const StudentAcademicCardWidget({super.key, required this.student});

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(13),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: const Color(0xFFDBEAFE),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: CustomIconWidget(
                      iconName: 'school',
                      size: 16,
                      color: const Color(0xFF1E40AF),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'Informações Acadêmicas',
                  style: GoogleFonts.manrope(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _AcademicRow(
              label: 'Turma',
              value: student.className,
              iconName: 'class',
            ),
            const SizedBox(height: 8),
            Container(height: 1, color: AppTheme.outlineVariantLight),
            const SizedBox(height: 8),
            _AcademicRow(
              label: 'Série',
              value: student.grade,
              iconName: 'grade',
            ),
            const SizedBox(height: 8),
            Container(height: 1, color: AppTheme.outlineVariantLight),
            const SizedBox(height: 8),
            _AcademicRow(
              label: 'Data de Nascimento',
              value: _formatDate(student.birthDate),
              iconName: 'cake',
            ),
            const SizedBox(height: 8),
            Container(height: 1, color: AppTheme.outlineVariantLight),
            const SizedBox(height: 8),
            _AcademicRow(
              label: 'Data de Matrícula',
              value: _formatDate(student.enrollmentDate),
              iconName: 'badge',
            ),
          ],
        ),
      ),
    );
  }
}

class _AcademicRow extends StatelessWidget {
  final String label;
  final String value;
  final String iconName;

  const _AcademicRow({
    required this.label,
    required this.value,
    required this.iconName,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        CustomIconWidget(iconName: iconName, size: 16, color: AppTheme.primary),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            label,
            style: GoogleFonts.manrope(
              fontSize: 13,
              fontWeight: FontWeight.w400,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
        Text(
          value,
          style: GoogleFonts.manrope(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: theme.colorScheme.onSurface,
          ),
        ),
      ],
    );
  }
}
