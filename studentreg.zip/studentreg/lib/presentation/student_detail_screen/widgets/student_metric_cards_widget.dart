import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';

// Anatomy locked: 2-column UNIFORM grid, each card: icon top-right + large value + label below

class StudentMetricCardsWidget extends StatelessWidget {
  final int age;
  final String enrollmentDate;
  final String birthDate;
  final String grade;

  const StudentMetricCardsWidget({
    super.key,
    required this.age,
    required this.enrollmentDate,
    required this.birthDate,
    required this.grade,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _MetricCard(
            iconName: 'cake',
            value: '$age',
            valueSuffix: ' anos',
            label: 'Idade',
            tintIndex: 0,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _MetricCard(
            iconName: 'calendar_today',
            value: enrollmentDate,
            label: 'Matrícula',
            tintIndex: 1,
            isSmallValue: true,
          ),
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String iconName;
  final String value;
  final String? valueSuffix;
  final String label;
  final int tintIndex;
  final bool isSmallValue;

  const _MetricCard({
    required this.iconName,
    required this.value,
    this.valueSuffix,
    required this.label,
    required this.tintIndex,
    this.isSmallValue = false,
  });

  static const List<Color> _tints = [Color(0xFFF0F4FF), Color(0xFFF0FBF4)];

  static const List<Color> _iconColors = [AppTheme.primary, AppTheme.success];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _tints[tintIndex % _tints.length],
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(13),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label,
                style: GoogleFonts.manrope(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: CustomIconWidget(
                    iconName: iconName,
                    size: 16,
                    color: _iconColors[tintIndex % _iconColors.length],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: value,
                  style: GoogleFonts.manrope(
                    fontSize: isSmallValue ? 16 : 26,
                    fontWeight: FontWeight.w800,
                    color: theme.colorScheme.onSurface,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
                if (valueSuffix != null)
                  TextSpan(
                    text: valueSuffix,
                    style: GoogleFonts.manrope(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
