import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../../routes/app_routes.dart';
import '../students_list_screen/students_list_screen.dart';
import './widgets/hero_image_section_widget.dart';
import './widgets/student_academic_card_widget.dart';
import './widgets/student_contact_card_widget.dart';
import './widgets/student_metric_cards_widget.dart';

// TODO: Replace with Riverpod/Bloc for production

class StudentDetailScreen extends StatefulWidget {
  const StudentDetailScreen({super.key});

  @override
  State<StudentDetailScreen> createState() => _StudentDetailScreenState();
}

class _StudentDetailScreenState extends State<StudentDetailScreen>
    with SingleTickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production

  late AnimationController _entranceController;
  Student? _student;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      if (args != null) {
        _student = args['student'] as Student?;
      }
      _initialized = true;
      _entranceController.forward();
    }
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  bool get _isTablet => MediaQuery.of(context).size.width >= 600;

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  void _onEdit() {
    if (_student == null) return;
    Navigator.pushNamed(
      context,
      AppRoutes.studentFormScreen,
      arguments: {'student': _student},
    ).then((result) {
      if (result != null && result is Student) {
        setState(() => _student = result);
        Navigator.pop(context, {'action': 'updated', 'student': result});
      }
    });
  }

  Future<void> _onDelete() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Excluir aluno',
          style: GoogleFonts.manrope(fontSize: 17, fontWeight: FontWeight.w700),
        ),
        content: Text(
          'Tem certeza que deseja excluir ${_student?.name}? Esta ação não pode ser desfeita.',
          style: GoogleFonts.manrope(fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(
              'Cancelar',
              style: GoogleFonts.manrope(fontWeight: FontWeight.w600),
            ),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: AppTheme.error),
            child: Text(
              'Excluir',
              style: GoogleFonts.manrope(
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
    if (confirm == true && mounted) {
      Navigator.pop(context, {'action': 'deleted', 'student': _student});
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_student == null) {
      return Scaffold(
        body: Center(
          child: EmptyStateWidget(
            iconName: 'person',
            title: 'Aluno não encontrado',
            subtitle: 'Não foi possível carregar os dados do aluno.',
            ctaLabel: 'Voltar',
            onCta: () => Navigator.pop(context),
          ),
        ),
      );
    }

    final student = _student!;
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: _isTablet
          ? _buildTabletLayout(student, theme)
          : _buildPhoneLayout(student, theme),
    );
  }

  Widget _buildPhoneLayout(Student student, ThemeData theme) {
    return Stack(
      children: [
        CustomScrollView(
          slivers: [
            // Hero image section
            SliverToBoxAdapter(
              child: HeroImageSectionWidget(
                student: student,
                onBack: () => Navigator.pop(context),
                onEdit: _onEdit,
                onDelete: _onDelete,
              ),
            ),
            // Content
            SliverToBoxAdapter(
              child: FadeTransition(
                opacity: CurvedAnimation(
                  parent: _entranceController,
                  curve: const Interval(0.3, 1.0, curve: Curves.easeOutCubic),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 20),
                      _buildNameHeader(student, theme),
                      const SizedBox(height: 20),
                      StudentMetricCardsWidget(
                        age: student.age,
                        enrollmentDate: _formatDate(student.enrollmentDate),
                        birthDate: _formatDate(student.birthDate),
                        grade: student.grade,
                      ),
                      const SizedBox(height: 16),
                      StudentAcademicCardWidget(student: student),
                      const SizedBox(height: 16),
                      StudentContactCardWidget(student: student),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        // Bottom action bar
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: _buildBottomActionBar(theme),
        ),
      ],
    );
  }

  Widget _buildTabletLayout(Student student, ThemeData theme) {
    return SafeArea(
      child: Row(
        children: [
          // Left panel: hero + name
          Expanded(
            flex: 4,
            child: Column(
              children: [
                HeroImageSectionWidget(
                  student: student,
                  onBack: () => Navigator.pop(context),
                  onEdit: _onEdit,
                  onDelete: _onDelete,
                  isTablet: true,
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: _buildNameHeader(student, theme),
                ),
              ],
            ),
          ),
          // Right panel: info
          Expanded(
            flex: 6,
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 24, 24, 24),
              child: FadeTransition(
                opacity: CurvedAnimation(
                  parent: _entranceController,
                  curve: const Interval(0.2, 1.0, curve: Curves.easeOutCubic),
                ),
                child: Column(
                  children: [
                    StudentMetricCardsWidget(
                      age: student.age,
                      enrollmentDate: _formatDate(student.enrollmentDate),
                      birthDate: _formatDate(student.birthDate),
                      grade: student.grade,
                    ),
                    const SizedBox(height: 16),
                    StudentAcademicCardWidget(student: student),
                    const SizedBox(height: 16),
                    StudentContactCardWidget(student: student),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _onDelete,
                            icon: CustomIconWidget(
                              iconName: 'delete',
                              size: 18,
                              color: AppTheme.error,
                            ),
                            label: Text(
                              'Excluir',
                              style: GoogleFonts.manrope(
                                fontWeight: FontWeight.w600,
                                color: AppTheme.error,
                              ),
                            ),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: AppTheme.error),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 2,
                          child: FilledButton.icon(
                            onPressed: _onEdit,
                            icon: CustomIconWidget(
                              iconName: 'edit',
                              size: 18,
                              color: Colors.white,
                            ),
                            label: Text(
                              'Editar Aluno',
                              style: GoogleFonts.manrope(
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                            style: FilledButton.styleFrom(
                              backgroundColor: AppTheme.primary,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNameHeader(Student student, ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          student.name,
          style: GoogleFonts.manrope(
            fontSize: 24,
            fontWeight: FontWeight.w800,
            color: theme.colorScheme.onSurface,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            StatusBadgeWidget(
              label: student.className,
              type: BadgeType.primary,
            ),
            const SizedBox(width: 8),
            StatusBadgeWidget(label: student.grade, type: BadgeType.info),
          ],
        ),
      ],
    );
  }

  Widget _buildBottomActionBar(ThemeData theme) {
    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        12,
        16,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(20),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: _onDelete,
              icon: CustomIconWidget(
                iconName: 'delete',
                size: 18,
                color: AppTheme.error,
              ),
              label: Text(
                'Excluir',
                style: GoogleFonts.manrope(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.error,
                ),
              ),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppTheme.error),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: FilledButton.icon(
              onPressed: _onEdit,
              icon: CustomIconWidget(
                iconName: 'edit',
                size: 18,
                color: Colors.white,
              ),
              label: Text(
                'Editar Aluno',
                style: GoogleFonts.manrope(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.primary,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
