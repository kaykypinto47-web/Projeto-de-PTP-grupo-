import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../students_list_screen.dart';

// Anatomy locked: large rounded card, tinted background, avatar left,
// name + grade/class info right, bottom row: class badge + action button

class StudentCardWidget extends StatelessWidget {
  final Student student;
  final VoidCallback onTap;
  final VoidCallback onEdit;

  const StudentCardWidget({
    super.key,
    required this.student,
    required this.onTap,
    required this.onEdit,
  });

  static const List<Color> _tintColors = [
    Color(0xFFF0F4FF),
    Color(0xFFF0FBF4),
    Color(0xFFFFF7F0),
    Color(0xFFF8F0FF),
    Color(0xFFFFF0F4),
  ];

  Color _getTint() {
    final idx = student.id.hashCode.abs() % _tintColors.length;
    return _tintColors[idx];
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        splashColor: AppTheme.primary.withAlpha(20),
        highlightColor: AppTheme.primary.withAlpha(10),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _getTint(),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(15),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              // Avatar with Hero transition
              Hero(
                tag: 'student-avatar-${student.id}',
                child: Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withAlpha(26),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: CustomImageWidget(
                      imageUrl: student.photoUrl,
                      width: 56,
                      height: 56,
                      fit: BoxFit.cover,
                      semanticLabel: student.photoSemanticLabel,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Name row + edit button
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            student.name,
                            style: GoogleFonts.manrope(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: theme.colorScheme.onSurface,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        InkWell(
                          onTap: onEdit,
                          borderRadius: BorderRadius.circular(999),
                          child: Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(
                              color: Colors.white.withAlpha(204),
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: CustomIconWidget(
                                iconName: 'edit',
                                size: 15,
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    // Email
                    Text(
                      student.email,
                      style: GoogleFonts.manrope(
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    // Bottom row: class badge + grade badge
                    Row(
                      children: [
                        _ClassBadge(label: student.className),
                        const SizedBox(width: 6),
                        _ClassBadge(label: student.grade, isGrade: true),
                        const Spacer(),
                        // Age
                        Text(
                          '${student.age} anos',
                          style: GoogleFonts.manrope(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ClassBadge extends StatelessWidget {
  final String label;
  final bool isGrade;

  const _ClassBadge({required this.label, this.isGrade = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: isGrade
            ? AppTheme.primaryContainer
            : Colors.white.withAlpha(230),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: GoogleFonts.manrope(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: isGrade
              ? AppTheme.primary
              : Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}
