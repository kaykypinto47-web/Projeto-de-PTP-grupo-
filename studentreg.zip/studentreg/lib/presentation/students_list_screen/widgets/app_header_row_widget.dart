import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';

class AppHeaderRowWidget extends StatelessWidget {
  final VoidCallback? onSearchTap;
  final VoidCallback? onNotificationTap;

  const AppHeaderRowWidget({
    super.key,
    this.onSearchTap,
    this.onNotificationTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(26),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: ClipOval(
            child: CustomImageWidget(
              imageUrl:
                  'https://images.pexels.com/photos/3184611/pexels-photo-3184611.jpeg?w=100',
              width: 44,
              height: 44,
              fit: BoxFit.cover,
              semanticLabel:
                  'School administrator profile photo, professional headshot',
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Escola Municipal',
                style: GoogleFonts.manrope(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              Text(
                'Administrador',
                style: GoogleFonts.manrope(
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
        _HeaderIconButton(
          iconName: 'search',
          onTap: onSearchTap,
          tooltip: 'Buscar',
        ),
        const SizedBox(width: 8),
        _HeaderIconButton(
          iconName: 'notifications',
          onTap: onNotificationTap,
          tooltip: 'Notificações',
          badgeCount: 2,
        ),
      ],
    );
  }
}

class _HeaderIconButton extends StatelessWidget {
  final String iconName;
  final VoidCallback? onTap;
  final String tooltip;
  final int badgeCount;

  const _HeaderIconButton({
    required this.iconName,
    this.onTap,
    required this.tooltip,
    this.badgeCount = 0,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        splashColor: AppTheme.primary.withAlpha(26),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(15),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Stack(
            children: [
              Center(
                child: CustomIconWidget(
                  iconName: iconName,
                  size: 20,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              if (badgeCount > 0)
                Positioned(
                  top: 6,
                  right: 6,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: AppTheme.error,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
