import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../../routes/app_routes.dart';
import './widgets/app_header_row_widget.dart';
import './widgets/search_filter_bar_widget.dart';
import './widgets/student_card_widget.dart';

// TODO: Replace with Riverpod/Bloc for production

class Student {
  final String id;
  final String name;
  final String photoUrl;
  final String photoSemanticLabel;
  final DateTime birthDate;
  final String className;
  final String grade;
  final String email;
  final String phone;
  final DateTime enrollmentDate;

  const Student({
    required this.id,
    required this.name,
    required this.photoUrl,
    required this.photoSemanticLabel,
    required this.birthDate,
    required this.className,
    required this.grade,
    required this.email,
    required this.phone,
    required this.enrollmentDate,
  });

  factory Student.fromMap(Map<String, dynamic> map) {
    return Student(
      id: map['id'] as String,
      name: map['name'] as String,
      photoUrl: map['photoUrl'] as String,
      photoSemanticLabel: map['semanticLabel'] as String,
      birthDate: DateTime.parse(map['birthDate'] as String),
      className: map['className'] as String,
      grade: map['grade'] as String,
      email: map['email'] as String,
      phone: map['phone'] as String,
      enrollmentDate: DateTime.parse(map['enrollmentDate'] as String),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'photoUrl': photoUrl,
      'semanticLabel': photoSemanticLabel,
      'birthDate': birthDate.toIso8601String(),
      'className': className,
      'grade': grade,
      'email': email,
      'phone': phone,
      'enrollmentDate': enrollmentDate.toIso8601String(),
    };
  }

  int get age {
    final now = DateTime.now();
    int age = now.year - birthDate.year;
    if (now.month < birthDate.month ||
        (now.month == birthDate.month && now.day < birthDate.day)) {
      age--;
    }
    return age;
  }

  Student copyWith({
    String? id,
    String? name,
    String? photoUrl,
    String? photoSemanticLabel,
    DateTime? birthDate,
    String? className,
    String? grade,
    String? email,
    String? phone,
    DateTime? enrollmentDate,
  }) {
    return Student(
      id: id ?? this.id,
      name: name ?? this.name,
      photoUrl: photoUrl ?? this.photoUrl,
      photoSemanticLabel: photoSemanticLabel ?? this.photoSemanticLabel,
      birthDate: birthDate ?? this.birthDate,
      className: className ?? this.className,
      grade: grade ?? this.grade,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      enrollmentDate: enrollmentDate ?? this.enrollmentDate,
    );
  }
}

final List<Map<String, dynamic>> _mockStudentMaps = [
  {
    'id': 's001',
    'name': 'Ana Beatriz Santos',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_1b3fbf659-1771906556456.png',
    'semanticLabel':
        'Young Brazilian woman with dark hair smiling, student portrait',
    'birthDate': '2010-03-15',
    'className': 'Turma A',
    'grade': '7º Ano',
    'email': 'ana.santos@escola.edu.br',
    'phone': '(11) 98765-4321',
    'enrollmentDate': '2024-02-01',
  },
  {
    'id': 's002',
    'name': 'Carlos Eduardo Oliveira',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_1b2d43c3d-1763299663618.png',
    'semanticLabel':
        'Young Brazilian boy with curly hair, casual school portrait',
    'birthDate': '2009-07-22',
    'className': 'Turma B',
    'grade': '8º Ano',
    'email': 'carlos.oliveira@escola.edu.br',
    'phone': '(11) 97654-3210',
    'enrollmentDate': '2024-02-01',
  },
  {
    'id': 's003',
    'name': 'Fernanda Lima',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_1b3fbf659-1771906556456.png',
    'semanticLabel': 'Brazilian girl with braided hair wearing school uniform',
    'birthDate': '2011-11-08',
    'className': 'Turma A',
    'grade': '6º Ano',
    'email': 'fernanda.lima@escola.edu.br',
    'phone': '(21) 99887-6543',
    'enrollmentDate': '2025-02-03',
  },
  {
    'id': 's004',
    'name': 'Gabriel Mendes Costa',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_1c3fedff2-1772270863270.png',
    'semanticLabel':
        'Young teenage boy with short dark hair and friendly smile',
    'birthDate': '2008-05-30',
    'className': 'Turma C',
    'grade': '9º Ano',
    'email': 'gabriel.costa@escola.edu.br',
    'phone': '(21) 98876-5432',
    'enrollmentDate': '2023-02-06',
  },
  {
    'id': 's005',
    'name': 'Isabela Rodrigues',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_1861c779f-1763301292730.png',
    'semanticLabel': 'Smiling Brazilian teenage girl with long dark hair',
    'birthDate': '2010-09-14',
    'className': 'Turma B',
    'grade': '7º Ano',
    'email': 'isabela.rodrigues@escola.edu.br',
    'phone': '(31) 97765-4321',
    'enrollmentDate': '2024-02-05',
  },
  {
    'id': 's006',
    'name': 'Lucas Pereira Alves',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_1188c22dd-1773010263235.png',
    'semanticLabel': 'Brazilian teenage boy with glasses and backpack',
    'birthDate': '2009-01-19',
    'className': 'Turma A',
    'grade': '8º Ano',
    'email': 'lucas.alves@escola.edu.br',
    'phone': '(31) 96654-3210',
    'enrollmentDate': '2023-02-07',
  },
  {
    'id': 's007',
    'name': 'Mariana Ferreira',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_10a397da6-1772094815227.png',
    'semanticLabel': 'Young girl with natural hair smiling confidently',
    'birthDate': '2012-04-25',
    'className': 'Turma C',
    'grade': '5º Ano',
    'email': 'mariana.ferreira@escola.edu.br',
    'phone': '(41) 98543-2109',
    'enrollmentDate': '2025-02-04',
  },
  {
    'id': 's008',
    'name': 'Pedro Henrique Souza',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_1ef57e344-1771906553794.png',
    'semanticLabel':
        'Brazilian teenage boy with straight hair wearing a blue shirt',
    'birthDate': '2008-12-03',
    'className': 'Turma B',
    'grade': '9º Ano',
    'email': 'pedro.souza@escola.edu.br',
    'phone': '(41) 97432-1098',
    'enrollmentDate': '2023-02-06',
  },
  {
    'id': 's009',
    'name': 'Sofia Carvalho Nunes',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_10c3f6864-1767158195171.png',
    'semanticLabel': 'Smiling girl with light brown hair in school setting',
    'birthDate': '2011-06-17',
    'className': 'Turma A',
    'grade': '6º Ano',
    'email': 'sofia.nunes@escola.edu.br',
    'phone': '(51) 99321-0987',
    'enrollmentDate': '2025-02-03',
  },
  {
    'id': 's010',
    'name': 'Thiago Nascimento',
    'photoUrl':
        'https://img.rocket.new/generatedImages/rocket_gen_img_13b7c6cfb-1772855184554.png',
    'semanticLabel': 'Teenage boy with afro hair wearing casual clothes',
    'birthDate': '2010-08-11',
    'className': 'Turma C',
    'grade': '7º Ano',
    'email': 'thiago.nascimento@escola.edu.br',
    'phone': '(51) 98210-9876',
    'enrollmentDate': '2024-02-05',
  },
  {
    'id': 's011',
    'name': 'Valentina Cruz',
    'photoUrl':
        'https://images.unsplash.com/photo-1616646468278-cbfa678fdc92',
    'semanticLabel': 'Young girl with curly hair and bright smile',
    'birthDate': '2013-02-28',
    'className': 'Turma A',
    'grade': '4º Ano',
    'email': 'valentina.cruz@escola.edu.br',
    'phone': '(61) 97109-8765',
    'enrollmentDate': '2026-02-03',
  },
  {
    'id': 's012',
    'name': 'Mateus Araújo Lima',
    'photoUrl':
        'https://images.unsplash.com/photo-1615868167768-6fe2e8eaacd8',
    'semanticLabel': 'Boy with dark skin and short hair, school photo',
    'birthDate': '2009-10-05',
    'className': 'Turma B',
    'grade': '8º Ano',
    'email': 'mateus.lima@escola.edu.br',
    'phone': '(61) 96098-7654',
    'enrollmentDate': '2023-02-06',
  },
];

class StudentsListScreen extends StatefulWidget {
  const StudentsListScreen({super.key});

  @override
  State<StudentsListScreen> createState() => _StudentsListScreenState();
}

class _StudentsListScreenState extends State<StudentsListScreen>
    with TickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc for production

  late List<Student> _allStudents;
  late List<Student> _filteredStudents;
  String _searchQuery = '';
  String _selectedClass = 'Todos';
  bool _isLoading = true;
  late AnimationController _listAnimController;

  final List<String> _classFilters = ['Todos', 'Turma A', 'Turma B', 'Turma C'];

  @override
  void initState() {
    super.initState();
    _allStudents = _mockStudentMaps.map(Student.fromMap).toList();
    _filteredStudents = List.from(_allStudents);
    _listAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    Future.microtask(() {
      if (mounted) {
        setState(() => _isLoading = false);
        _listAnimController.forward();
      }
    });
  }

  @override
  void dispose() {
    _listAnimController.dispose();
    super.dispose();
  }

  void _applyFilters() {
    setState(() {
      _filteredStudents = _allStudents.where((s) {
        final matchesSearch =
            _searchQuery.isEmpty ||
            s.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            s.className.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            s.grade.toLowerCase().contains(_searchQuery.toLowerCase());
        final matchesClass =
            _selectedClass == 'Todos' || s.className == _selectedClass;
        return matchesSearch && matchesClass;
      }).toList();
    });
  }

  void _onSearchChanged(String query) {
    _searchQuery = query;
    _applyFilters();
  }

  void _onClassSelected(String className) {
    setState(() => _selectedClass = className);
    _applyFilters();
  }

  Future<void> _onRefresh() async {
    // TODO: Replace with real data fetch
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 800));
    if (mounted) {
      setState(() {
        _allStudents = _mockStudentMaps.map(Student.fromMap).toList();
        _filteredStudents = List.from(_allStudents);
        _isLoading = false;
        _searchQuery = '';
        _selectedClass = 'Todos';
      });
      _listAnimController
        ..reset()
        ..forward();
    }
  }

  void _deleteStudent(Student student) {
    setState(() {
      _allStudents.removeWhere((s) => s.id == student.id);
      _filteredStudents.removeWhere((s) => s.id == student.id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '${student.name} removido',
          style: GoogleFonts.manrope(fontSize: 13, fontWeight: FontWeight.w500),
        ),
        action: SnackBarAction(
          label: 'Desfazer',
          onPressed: () {
            setState(() {
              _allStudents.add(student);
              _allStudents.sort((a, b) => a.name.compareTo(b.name));
              _applyFilters();
            });
          },
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _navigateToDetail(Student student) {
    Navigator.pushNamed(
      context,
      AppRoutes.studentDetailScreen,
      arguments: {'student': student},
    ).then((result) {
      if (result != null && result is Map) {
        if (result['action'] == 'deleted') {
          _deleteStudent(result['student'] as Student);
        } else if (result['action'] == 'updated') {
          final updated = result['student'] as Student;
          setState(() {
            final idx = _allStudents.indexWhere((s) => s.id == updated.id);
            if (idx != -1) _allStudents[idx] = updated;
            _applyFilters();
          });
        }
      }
    });
  }

  void _navigateToForm({Student? student}) {
    Navigator.pushNamed(
      context,
      AppRoutes.studentFormScreen,
      arguments: student != null ? {'student': student} : null,
    ).then((result) {
      if (result != null && result is Student) {
        setState(() {
          final idx = _allStudents.indexWhere((s) => s.id == result.id);
          if (idx != -1) {
            _allStudents[idx] = result;
          } else {
            _allStudents.add(result);
          }
          _applyFilters();
        });
        _listAnimController
          ..reset()
          ..forward();
      }
    });
  }

  bool get _isTablet => MediaQuery.of(context).size.width >= 600;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _onRefresh,
          color: AppTheme.primary,
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AppHeaderRowWidget(
                        onSearchTap: () {},
                        onNotificationTap: () {},
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Alunos',
                                  style: GoogleFonts.manrope(
                                    fontSize: 26,
                                    fontWeight: FontWeight.w800,
                                    color: theme.colorScheme.onSurface,
                                  ),
                                ),
                                Text(
                                  '${_filteredStudents.length} cadastrado${_filteredStudents.length != 1 ? 's' : ''}',
                                  style: GoogleFonts.manrope(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w400,
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      SearchFilterBarWidget(
                        onSearchChanged: _onSearchChanged,
                        selectedClass: _selectedClass,
                        classFilters: _classFilters,
                        onClassSelected: _onClassSelected,
                      ),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ),
              if (_isLoading)
                const SliverFillRemaining(child: StudentListSkeletonWidget())
              else if (_filteredStudents.isEmpty)
                SliverFillRemaining(
                  child: EmptyStateWidget(
                    iconName: 'group',
                    title: 'Nenhum aluno encontrado',
                    subtitle:
                        _searchQuery.isNotEmpty || _selectedClass != 'Todos'
                        ? 'Tente ajustar os filtros de busca.'
                        : 'Comece cadastrando o primeiro aluno da turma.',
                    ctaLabel: _searchQuery.isEmpty && _selectedClass == 'Todos'
                        ? 'Cadastrar Aluno'
                        : null,
                    onCta: _searchQuery.isEmpty && _selectedClass == 'Todos'
                        ? () => _navigateToForm()
                        : null,
                  ),
                )
              else
                SliverPadding(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  sliver: _isTablet
                      ? SliverGrid(
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                mainAxisSpacing: 12,
                                crossAxisSpacing: 12,
                                childAspectRatio: 1.6,
                              ),
                          delegate: SliverChildBuilderDelegate(
                            (context, index) => _buildAnimatedCard(index),
                            childCount: _filteredStudents.length,
                          ),
                        )
                      : SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (context, index) => Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: _buildAnimatedCard(index),
                            ),
                            childCount: _filteredStudents.length,
                          ),
                        ),
                ),
              const SliverToBoxAdapter(child: SizedBox(height: 96)),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _navigateToForm(),
        icon: const Icon(Icons.person_add_rounded),
        label: Text(
          'Novo Aluno',
          style: GoogleFonts.manrope(fontSize: 14, fontWeight: FontWeight.w600),
        ),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
      ),
    );
  }

  Widget _buildAnimatedCard(int index) {
    final delay = (index * 60).clamp(0, 400);
    final animation = CurvedAnimation(
      parent: _listAnimController,
      curve: Interval(
        delay / 1000.0,
        (delay / 1000.0 + 0.4).clamp(0.0, 1.0),
        curve: Curves.easeOutCubic,
      ),
    );

    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, 20 * (1 - animation.value)),
          child: Opacity(
            opacity: animation.value.clamp(0.0, 1.0),
            child: child,
          ),
        );
      },
      child: Dismissible(
        key: Key(_filteredStudents[index].id),
        direction: DismissDirection.endToStart,
        background: Container(
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.only(right: 20),
          decoration: BoxDecoration(
            color: AppTheme.error,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.delete_outline_rounded,
                color: Colors.white,
                size: 24,
              ),
              const SizedBox(height: 4),
              Text(
                'Excluir',
                style: GoogleFonts.manrope(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        confirmDismiss: (_) async {
          return await _showDeleteConfirmation(_filteredStudents[index]);
        },
        onDismissed: (_) => _deleteStudent(_filteredStudents[index]),
        child: StudentCardWidget(
          student: _filteredStudents[index],
          onTap: () => _navigateToDetail(_filteredStudents[index]),
          onEdit: () => _navigateToForm(student: _filteredStudents[index]),
        ),
      ),
    );
  }

  Future<bool> _showDeleteConfirmation(Student student) async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text(
              'Excluir aluno',
              style: GoogleFonts.manrope(
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),
            content: Text(
              'Tem certeza que deseja excluir ${student.name}? Esta ação não pode ser desfeita.',
              style: GoogleFonts.manrope(fontSize: 14),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(
                  'Cancelar',
                  style: GoogleFonts.manrope(fontWeight: FontWeight.w600),
                ),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                style: FilledButton.styleFrom(backgroundColor: AppTheme.error),
                child: Text(
                  'Excluir',
                  style: GoogleFonts.manrope(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ) ??
        false;
  }
}
