import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

enum BadgeType { primary, success, warning, error, neutral, info }

class StatusBadgeWidget extends StatelessWidget {
  final String label;
  final BadgeType type;
  final double? fontSize;

  const StatusBadgeWidget({
    super.key,
    required this.label,
    this.type = BadgeType.primary,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    final colors = _getColors(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: colors.$1,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: GoogleFonts.manrope(
          fontSize: fontSize ?? 11,
          fontWeight: FontWeight.w600,
          color: colors.$2,
          letterSpacing: 0.2,
        ),
      ),
    );
  }

  (Color, Color) _getColors(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    switch (type) {
      case BadgeType.primary:
        return (scheme.primaryContainer, scheme.onPrimaryContainer);
      case BadgeType.success:
        return (const Color(0xFFD1FAE5), const Color(0xFF065F46));
      case BadgeType.warning:
        return (const Color(0xFFFEF3C7), const Color(0xFF92400E));
      case BadgeType.error:
        return (const Color(0xFFFEE2E2), const Color(0xFF991B1B));
      case BadgeType.neutral:
        return (scheme.surfaceContainerHighest, scheme.onSurfaceVariant);
      case BadgeType.info:
        return (const Color(0xFFDBEAFE), const Color(0xFF1E40AF));
    }
  }
}
