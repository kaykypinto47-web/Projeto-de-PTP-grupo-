import 'package:flutter/material.dart';

import '../presentation/student_detail_screen/student_detail_screen.dart';
import '../presentation/student_form_screen/student_form_screen.dart';
import '../presentation/students_list_screen/students_list_screen.dart';

class AppRoutes {
  static const String initial = '/';
  static const String studentsListScreen = '/students-list-screen';
  static const String studentFormScreen = '/student-form-screen';
  static const String studentDetailScreen = '/student-detail-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const StudentsListScreen(),
    studentsListScreen: (context) => const StudentsListScreen(),
    studentFormScreen: (context) => const StudentFormScreen(),
    studentDetailScreen: (context) => const StudentDetailScreen(),
  };
}
