# 📚 Cadastro de Estudantes - Flutter

Aplicativo simples de cadastro de estudantes em Flutter, com persistência em arquivo JSON local.

## 🚀 Como rodar no Android Studio

### 1. Pré-requisitos
- Android Studio instalado
- Plugin **Flutter** e **Dart** instalados (em `File → Settings → Plugins`)
- Flutter SDK configurado (rode `flutter doctor` para verificar)

### 2. Criar o projeto base
No Android Studio:
1. `File → New → New Flutter Project`
2. Selecione **Flutter Application**
3. Nome do projeto: `cadastro_estudantes`
4. Aguarde a criação

### 3. Substituir os arquivos
Após o projeto ser criado, **substitua** os seguintes arquivos pelos que estão aqui:

| Arquivo do projeto | Substituir pelo arquivo deste pacote |
|---|---|
| `pubspec.yaml` | `pubspec.yaml` |
| `lib/main.dart` | `lib/main.dart` |

### 4. Instalar dependências
No terminal do Android Studio (View → Tool Windows → Terminal):
```bash
flutter pub get
```

Ou clique em **"Pub get"** que aparece no topo ao abrir o `pubspec.yaml`.

### 5. Rodar o app
- Conecte um emulador Android ou um dispositivo físico
- Clique no botão ▶️ **Run** (ou pressione `Shift + F10`)

## 📦 Dependência usada
- `path_provider`: para acessar o diretório de documentos do app e salvar o arquivo `estudantes.json`

## ✨ Funcionalidades
- ➕ Cadastrar estudante (nome, idade, e-mail, curso)
- 📋 Listar estudantes em cards
- 🗑️ Remover estudante com confirmação
- 💾 Persistência automática em arquivo JSON local

## 📁 Onde os dados são salvos
Em um arquivo `estudantes.json` dentro do diretório de documentos do aplicativo (acessível apenas pelo próprio app).
