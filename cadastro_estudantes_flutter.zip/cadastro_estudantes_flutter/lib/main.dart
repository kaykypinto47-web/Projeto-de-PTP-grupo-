import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cadastro de Estudantes',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Estudante {
  String nome;
  String idade;
  String email;
  String curso;

  Estudante({
    required this.nome,
    required this.idade,
    required this.email,
    required this.curso,
  });

  Map<String, dynamic> toJson() => {
        'nome': nome,
        'idade': idade,
        'email': email,
        'curso': curso,
      };

  factory Estudante.fromJson(Map<String, dynamic> j) => Estudante(
        nome: j['nome'] ?? '',
        idade: j['idade']?.toString() ?? '',
        email: j['email'] ?? '',
        curso: j['curso'] ?? '',
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Estudante> estudantes = [];

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  Future<File> _arquivo() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/estudantes.json');
  }

  Future<void> _carregar() async {
    try {
      final f = await _arquivo();
      if (await f.exists()) {
        final dados = jsonDecode(await f.readAsString()) as List;
        setState(() {
          estudantes = dados.map((e) => Estudante.fromJson(e)).toList();
        });
      }
    } catch (_) {}
  }

  Future<void> _salvar() async {
    final f = await _arquivo();
    await f.writeAsString(
      jsonEncode(estudantes.map((e) => e.toJson()).toList()),
    );
  }

  void _adicionar() async {
    final novo = await showDialog<Estudante>(
      context: context,
      builder: (_) => const FormDialog(),
    );
    if (novo != null) {
      setState(() => estudantes.add(novo));
      _salvar();
    }
  }

  void _remover(int i) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remover estudante?'),
        content: Text(estudantes[i].nome),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Remover'),
          ),
        ],
      ),
    );
    if (ok == true) {
      setState(() => estudantes.removeAt(i));
      _salvar();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📚 Cadastro de Estudantes'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: estudantes.isEmpty
          ? const Center(
              child: Text(
                'Nenhum estudante cadastrado',
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: estudantes.length,
              itemBuilder: (_, i) {
                final e = estudantes[i];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Text(e.nome.isNotEmpty ? e.nome[0].toUpperCase() : '?'),
                    ),
                    title: Text(e.nome),
                    subtitle: Text('${e.curso} • ${e.idade} anos\n${e.email}'),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _remover(i),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _adicionar,
        child: const Icon(Icons.add),
      ),
    );
  }
}

class FormDialog extends StatefulWidget {
  const FormDialog({super.key});
  @override
  State<FormDialog> createState() => _FormDialogState();
}

class _FormDialogState extends State<FormDialog> {
  final _formKey = GlobalKey<FormState>();
  final nome = TextEditingController();
  final idade = TextEditingController();
  final email = TextEditingController();
  final curso = TextEditingController();

  @override
  void dispose() {
    nome.dispose();
    idade.dispose();
    email.dispose();
    curso.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Novo Estudante'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nome,
                decoration: const InputDecoration(labelText: 'Nome'),
                validator: (v) => v!.isEmpty ? 'Obrigatório' : null,
              ),
              TextFormField(
                controller: idade,
                decoration: const InputDecoration(labelText: 'Idade'),
                keyboardType: TextInputType.number,
                validator: (v) => v!.isEmpty ? 'Obrigatório' : null,
              ),
              TextFormField(
                controller: email,
                decoration: const InputDecoration(labelText: 'E-mail'),
                keyboardType: TextInputType.emailAddress,
                validator: (v) => v!.isEmpty ? 'Obrigatório' : null,
              ),
              TextFormField(
                controller: curso,
                decoration: const InputDecoration(labelText: 'Curso'),
                validator: (v) => v!.isEmpty ? 'Obrigatório' : null,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              Navigator.pop(
                context,
                Estudante(
                  nome: nome.text,
                  idade: idade.text,
                  email: email.text,
                  curso: curso.text,
                ),
              );
            }
          },
          child: const Text('Salvar'),
        ),
      ],
    );
  }
}
